package HW190612;

public class Number {

	private int num1, num2;

	public Number(int num1, int num2) {
		this.num1 = num1;
		this.num2 = num2;
	}

	public String getNumber() {
		return "ù��° ��: " + num1 + ", �ι�° ��: " + num2;
	}
	
	
	
}
